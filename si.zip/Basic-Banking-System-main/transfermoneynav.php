<header>
        <div class="logoimg">
            <img src="static/logo.png" alt="logo">
        </div>
        <div class="logo">Pro Bank</div>
        <div class="navigation">
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="createuser.php">Create User</a></li>
                <li><a class="active" href="transfermoney.php">Transfer Money</a></li>
                <li><a href="transactionhistory.php">Transaction History</a></li>
            </ul>
        </div>
</header>